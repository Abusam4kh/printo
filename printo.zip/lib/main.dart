import 'package:flutter/material.dart';

void main() => runApp(const PrintoApp());

const Color printoNavy = Color(0xFF172B4D);
const Color printoBlue = Color(0xFF356AE6);
const Color printoBackground = Color(0xFFF5F7FB);

class PrintoApp extends StatelessWidget {
  const PrintoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PRINTO | برينتو',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: printoBackground,
        colorScheme: ColorScheme.fromSeed(seedColor: printoBlue),
        appBarTheme: const AppBarTheme(
          backgroundColor: printoBackground,
          foregroundColor: printoNavy,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFE8ECF4)),
          ),
        ),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: PrintoHomePage(),
      ),
    );
  }
}

class PrintoHomePage extends StatelessWidget {
  const PrintoHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final tools = <PrintTool>[
      const PrintTool('بطاقة شخصية', 'تجهيز الوجهين للطباعة', Icons.badge_outlined, Color(0xFFE8EEFF), printoBlue),
      const PrintTool('صورة شخصية', 'قص وتجهيز مقاسات الصور', Icons.person_outline_rounded, Color(0xFFE5F6EF), Color(0xFF16845B)),
      const PrintTool('تصوير مستند', 'قص الحواف وتصحيح المنظور', Icons.document_scanner_outlined, Color(0xFFFFF0DB), Color(0xFFB76A08)),
      const PrintTool('صور متعددة', 'ترتيب صور على ورقة واحدة', Icons.grid_view_rounded, Color(0xFFF3E8FF), Color(0xFF8546B8)),
      const PrintTool('صور إلى PDF', 'تجهيز ملف للطباعة', Icons.picture_as_pdf_outlined, Color(0xFFFFE8E8), Color(0xFFC63B3B)),
      const PrintTool('مقاس مخصص', 'حدد العرض والارتفاع', Icons.straighten_rounded, Color(0xFFE2F4F7), Color(0xFF147C8A)),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('برينتو', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'الإعدادات',
            onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const Directionality(textDirection: TextDirection.rtl, child: SettingsPage()))),
            icon: const Icon(Icons.settings_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 6, 18, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [Color(0xFF244B9A), Color(0xFF172B4D)],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(30)),
                    child: const Text('PRINTO  •  الطباعة الذكية', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(height: 18),
                  const Text('من الصورة إلى الورقة، بسهولة.', style: TextStyle(color: Colors.white, fontSize: 23, height: 1.35, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  Text('جهّز صورك ومستنداتك للطباعة بمقاسات دقيقة.', style: TextStyle(color: Colors.white.withValues(alpha: 0.82), fontSize: 14, height: 1.6)),
                  const SizedBox(height: 20),
                  FilledButton.icon(
                    onPressed: () => _openTool(context, tools.first),
                    style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: printoNavy, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13)),
                    icon: const Icon(Icons.arrow_back_rounded),
                    label: const Text('ابدأ ببطاقة شخصية', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 26),
            const Text('ماذا تريد أن تطبع؟', style: TextStyle(fontSize: 19, color: printoNavy, fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            const Text('اختر أداة للبدء', style: TextStyle(color: Color(0xFF758198), fontSize: 13)),
            const SizedBox(height: 14),
            GridView.builder(
              itemCount: tools.length,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.94),
              itemBuilder: (context, index) {
                final tool = tools[index];
                return InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () => _openTool(context, tool),
                  child: Card(
                    margin: EdgeInsets.zero,
                    child: Padding(
                      padding: const EdgeInsets.all(15),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(width: 48, height: 48, decoration: BoxDecoration(color: tool.color, borderRadius: BorderRadius.circular(15)), child: Icon(tool.icon, color: tool.iconColor, size: 26)),
                          const Spacer(),
                          Text(tool.title, style: const TextStyle(fontSize: 15, color: printoNavy, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 5),
                          Text(tool.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, height: 1.45, color: Color(0xFF758198))),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE8ECF4))),
              child: const Row(
                children: [
                  Icon(Icons.offline_bolt_outlined, color: printoBlue, size: 25),
                  SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('مصمم للعمل على هاتفك', style: TextStyle(color: printoNavy, fontWeight: FontWeight.w700)),
                    SizedBox(height: 3),
                    Text('هدفنا تجهيز الصور والملفات محلياً دون رفعها إلى الإنترنت.', style: TextStyle(color: Color(0xFF758198), fontSize: 12, height: 1.5)),
                  ])),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openTool(BuildContext context, PrintTool tool) {
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ToolIntroPage(tool: tool)));
  }
}

class PrintTool {
  const PrintTool(this.title, this.subtitle, this.icon, this.color, this.iconColor);
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final Color iconColor;
}

class ToolIntroPage extends StatelessWidget {
  const ToolIntroPage({super.key, required this.tool});
  final PrintTool tool;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(tool.title)),
    body: Padding(
      padding: const EdgeInsets.all(22),
      child: Column(children: [
        const SizedBox(height: 25),
        Container(width: 90, height: 90, decoration: BoxDecoration(color: tool.color, borderRadius: BorderRadius.circular(26)), child: Icon(tool.icon, color: tool.iconColor, size: 45)),
        const SizedBox(height: 22),
        Text(tool.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: printoNavy)),
        const SizedBox(height: 10),
        Text(tool.subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF758198), fontSize: 15, height: 1.7)),
        const SizedBox(height: 24),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE8ECF4))),
          child: const Text('هذه واجهة تمهيدية. ستضاف في المرحلة التالية وظائف التصوير الفعلي، والقص التلقائي، وضبط المقاسات، ومعاينة ملف الطباعة.', textAlign: TextAlign.center, style: TextStyle(height: 1.7, color: printoNavy)),
        ),
        const Spacer(),
        SizedBox(width: double.infinity, child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('العودة للرئيسية'))),
      ]),
    ),
  );
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الإعدادات')),
    body: ListView(padding: const EdgeInsets.all(18), children: const [
      ListTile(leading: Icon(Icons.straighten_outlined, color: printoBlue), title: Text('وحدات القياس'), subtitle: Text('ستكون مقاسات الطباعة بالملليمتر.')),
      Divider(height: 1),
      ListTile(leading: Icon(Icons.print_outlined, color: printoBlue), title: Text('إعدادات الطباعة'), subtitle: Text('ستضاف خيارات الورق والهوامش والطابعة لاحقاً.')),
      Divider(height: 1),
      ListTile(leading: Icon(Icons.info_outline, color: printoBlue), title: Text('حول برينتو'), subtitle: Text('PRINTO — الطباعة الذكية في متناول يدك.')),
    ]),
  );
}
