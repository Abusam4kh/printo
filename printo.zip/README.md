# PRINTO | برينتو

هذه نسخة تأسيسية من تطبيق Flutter. واجهة الأدوات تمهيدية؛ الكاميرا ومعالجة الصور وتصدير PDF ستضاف في المراحل التالية.

## استخدام GitHub Actions مع رفع ملف ZIP
1. ارفع `printo.zip` إلى جذر مستودع GitHub.
2. تأكد أن ملف `.github/workflows/build-from-zip.yml` موجود في جذر المستودع خارج الأرشيف، حتى يستطيع GitHub Actions اكتشافه.
3. شغّل Workflow باسم `Build PRINTO from ZIP`.
4. سيقوم الـ Workflow بفك `printo.zip` واستخراج مجلد `project` ثم بناء APK.
5. نزّل Artifact باسم `printo-release-apk`.

مهم: GitHub Actions لا يستطيع تشغيل Workflow موجود داخل ملف ZIP قبل فكّه؛ لذلك يجب أن يكون ملف الـ workflow نفسه مرفوعاً بشكل منفصل إلى `.github/workflows/` في المستودع.
