import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

void main() => runApp(const PrintoApp());

const Color printoNavy = Color(0xFF172B4D);
const Color printoBlue = Color(0xFF356AE6);
const Color printoBackground = Color(0xFFF5F7FB);

class PrintoApp extends StatelessWidget {
  const PrintoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'PRINTO | برينتو', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: printoBackground,
      colorScheme: ColorScheme.fromSeed(seedColor: printoBlue),
      appBarTheme: const AppBarTheme(backgroundColor: printoBackground, foregroundColor: printoNavy, elevation: 0),
      cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFFE8ECF4))))),
    home: const Directionality(textDirection: TextDirection.rtl, child: PrintoHomePage()),
  );
}

class PrintoHomePage extends StatelessWidget {
  const PrintoHomePage({super.key});
  @override
  Widget build(BuildContext context) {
    final tools = <PrintTool>[
      const PrintTool('بطاقة شخصية', 'تجهيز الوجهين للطباعة', Icons.badge_outlined, Color(0xFFE8EEFF), printoBlue),
      const PrintTool('صورة شخصية', 'قص وتجهيز مقاسات الصور', Icons.person_outline_rounded, Color(0xFFE5F6EF), Color(0xFF16845B)),
      const PrintTool('تصوير مستند', 'قص الحواف وتصحيح المنظور', Icons.document_scanner_outlined, Color(0xFFFFF0DB), Color(0xFFB76A08)),
      const PrintTool('صور متعددة', 'ترتيب صور على ورقة واحدة', Icons.grid_view_rounded, Color(0xFFF3E8FF), Color(0xFF8546B8)),
      const PrintTool('صور إلى PDF', 'تجهيز ملف للطباعة', Icons.picture_as_pdf_outlined, Color(0xFFFFE8E8), Color(0xFFC63B3B)),
      const PrintTool('مقاس مخصص', 'حدد العرض والارتفاع', Icons.straighten_rounded, Color(0xFFE2F4F7), Color(0xFF147C8A)),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('برينتو', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)), actions: [IconButton(tooltip: 'الإعدادات', onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const SettingsPage())), icon: const Icon(Icons.settings_outlined))]),
      body: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(18, 6, 18, 28), children: [
        Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF244B9A), printoNavy])), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .14), borderRadius: BorderRadius.circular(30)), child: const Text('PRINTO  •  الطباعة الذكية', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600))),
          const SizedBox(height: 18), const Text('من الصورة إلى الورقة، بسهولة.', style: TextStyle(color: Colors.white, fontSize: 23, height: 1.35, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8), Text('جهّز صورك ومستنداتك للطباعة بمقاسات دقيقة.', style: TextStyle(color: Colors.white.withValues(alpha: .82), fontSize: 14, height: 1.6)),
          const SizedBox(height: 20), FilledButton.icon(onPressed: () => _openTool(context, tools.first), style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: printoNavy, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13)), icon: const Icon(Icons.arrow_back_rounded), label: const Text('ابدأ ببطاقة شخصية', style: TextStyle(fontWeight: FontWeight.bold))),
        ])),
        const SizedBox(height: 26), const Text('ماذا تريد أن تطبع؟', style: TextStyle(fontSize: 19, color: printoNavy, fontWeight: FontWeight.w800)),
        const SizedBox(height: 5), const Text('اختر أداة للبدء', style: TextStyle(color: Color(0xFF758198), fontSize: 13)), const SizedBox(height: 14),
        GridView.builder(itemCount: tools.length, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .94), itemBuilder: (context, index) { final tool = tools[index]; return InkWell(borderRadius: BorderRadius.circular(20), onTap: () => _openTool(context, tool), child: Card(margin: EdgeInsets.zero, child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(width: 48, height: 48, decoration: BoxDecoration(color: tool.color, borderRadius: BorderRadius.circular(15)), child: Icon(tool.icon, color: tool.iconColor, size: 26)), const Spacer(), Text(tool.title, style: const TextStyle(fontSize: 15, color: printoNavy, fontWeight: FontWeight.w800)), const SizedBox(height: 5), Text(tool.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, height: 1.45, color: Color(0xFF758198)))]))));}),
        const SizedBox(height: 20), Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE8ECF4))), child: const Row(children: [Icon(Icons.offline_bolt_outlined, color: printoBlue, size: 25), SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('مصمم للعمل على هاتفك', style: TextStyle(color: printoNavy, fontWeight: FontWeight.w700)), SizedBox(height: 3), Text('تتم معالجة الصور محلياً على الهاتف دون رفعها إلى الإنترنت.', style: TextStyle(color: Color(0xFF758198), fontSize: 12, height: 1.5))]))])),
      ])),
    );
  }
  void _openTool(BuildContext context, PrintTool tool) {
    if (tool.title == 'بطاقة شخصية') { Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const IdCardPage())); }
    else { Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ToolIntroPage(tool: tool))); }
  }
}

class PrintTool { const PrintTool(this.title, this.subtitle, this.icon, this.color, this.iconColor); final String title, subtitle; final IconData icon; final Color color, iconColor; }

class IdCardPage extends StatefulWidget { const IdCardPage({super.key}); @override State<IdCardPage> createState() => _IdCardPageState(); }
class _IdCardPageState extends State<IdCardPage> {
  final ImagePicker _picker = ImagePicker();
  XFile? _front, _back;
  bool _busy = false;
  // Standard ISO/IEC ID-1 card size: 85.60 × 53.98 mm. Verify the physical card size if it differs.
  double _widthMm = 85.6, _heightMm = 53.98;

  Future<void> _selectImage(bool front, ImageSource source) async {
    try {
      final picked = await _picker.pickImage(source: source, imageQuality: 100, preferredCameraDevice: CameraDevice.rear);
      if (picked == null || !mounted) return;
      setState(() => _busy = true);
      final cropped = await ImageCropper().cropImage(
        sourcePath: picked.path,
        compressQuality: 100,
        uiSettings: [AndroidUiSettings(toolbarTitle: front ? 'قص الوجه الأمامي' : 'قص الوجه الخلفي', toolbarColor: printoNavy, toolbarWidgetColor: Colors.white, activeControlsWidgetColor: printoBlue, lockAspectRatio: false, hideBottomControls: false), IOSUiSettings(title: front ? 'قص الوجه الأمامي' : 'قص الوجه الخلفي')],
      );
      if (!mounted) return;
      if (cropped != null) setState(() { if (front) { _front = XFile(cropped.path); } else { _back = XFile(cropped.path); } });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر فتح الصورة: $e')));
    } finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _showSourceOptions(bool front) async {
    showModalBottomSheet<void>(context: context, builder: (sheetContext) => SafeArea(child: Wrap(children: [
      ListTile(leading: const Icon(Icons.camera_alt_outlined), title: const Text('التقاط صورة بالكاميرا'), onTap: () { Navigator.pop(sheetContext); _selectImage(front, ImageSource.camera); }),
      ListTile(leading: const Icon(Icons.photo_library_outlined), title: const Text('اختيار من المعرض'), onTap: () { Navigator.pop(sheetContext); _selectImage(front, ImageSource.gallery); }),
    ])));
  }

  Future<Uint8List> _buildPdf(PdfPageFormat format) async {
    final doc = pw.Document();
    final frontBytes = _front == null ? null : await File(_front!.path).readAsBytes();
    final backBytes = _back == null ? null : await File(_back!.path).readAsBytes();
    final cardW = _widthMm * PdfPageFormat.mm;
    final cardH = _heightMm * PdfPageFormat.mm;
    doc.addPage(pw.Page(pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(18 * PdfPageFormat.mm), build: (context) {
      final content = <pw.Widget>[];
      if (frontBytes != null) content.add(pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [pw.Text('الوجه الأمامي', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)), pw.SizedBox(height: 3 * PdfPageFormat.mm), pw.Container(width: cardW, height: cardH, child: pw.Image(pw.MemoryImage(frontBytes), fit: pw.BoxFit.fill)), pw.SizedBox(height: 10 * PdfPageFormat.mm)]));
      if (backBytes != null) content.add(pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [pw.Text('الوجه الخلفي', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)), pw.SizedBox(height: 3 * PdfPageFormat.mm), pw.Container(width: cardW, height: cardH, child: pw.Image(pw.MemoryImage(backBytes), fit: pw.BoxFit.fill))]));
      return pw.Align(alignment: pw.Alignment.topCenter, child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: content));
    }));
    return doc.save();
  }

  Future<void> _previewPdf() async {
    if (_front == null && _back == null) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أضف صورة الوجه الأمامي أو الخلفي أولاً.'))); return; }
    await Printing.layoutPdf(onLayout: _buildPdf, name: 'PRINTO_ID_Card.pdf');
  }

  Widget _sideCard({required String title, required bool front, required XFile? file}) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [Icon(front ? Icons.credit_card : Icons.flip_to_back_outlined, color: printoBlue), const SizedBox(width: 8), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: printoNavy))), if (file != null) IconButton(tooltip: 'حذف الصورة', onPressed: () => setState(() { if (front) { _front = null; } else { _back = null; } }), icon: const Icon(Icons.delete_outline, color: Colors.redAccent))]),
    const SizedBox(height: 8), AspectRatio(aspectRatio: 1.586, child: InkWell(onTap: () => _showSourceOptions(front), borderRadius: BorderRadius.circular(12), child: Container(decoration: BoxDecoration(color: const Color(0xFFF5F7FB), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFDDE4F0))), clipBehavior: Clip.antiAlias, child: file == null ? const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.add_a_photo_outlined, size: 32, color: printoBlue), SizedBox(height: 8), Text('اضغط لإضافة الصورة', style: TextStyle(color: printoNavy, fontSize: 12))]) : Image.file(File(file.path), fit: BoxFit.contain)))),
    const SizedBox(height: 10), SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: _busy ? null : () => _showSourceOptions(front), icon: const Icon(Icons.edit_outlined), label: Text(file == null ? 'التقاط أو اختيار صورة' : 'تغيير الصورة'))),
  ])));

  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('تجهيز بطاقة شخصية')), body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
    Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFE8EEFF), borderRadius: BorderRadius.circular(16)), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline, color: printoBlue), SizedBox(width: 10), Expanded(child: Text('التقط أو اختر صورة لكل وجه، ثم اضبط القص. سيُجهز التطبيق الوجهين على ورقة A4 بمقاس البطاقة المحدد.', style: TextStyle(color: printoNavy, height: 1.6, fontSize: 13)))])),
    const SizedBox(height: 12), _sideCard(title: 'الوجه الأمامي', front: true, file: _front), const SizedBox(height: 12), _sideCard(title: 'الوجه الخلفي', front: false, file: _back),
    const SizedBox(height: 18), const Text('مقاس البطاقة للطباعة', style: TextStyle(color: printoNavy, fontWeight: FontWeight.w800, fontSize: 16)), const SizedBox(height: 4), const Text('المقاس الافتراضي هو المقاس القياسي للبطاقات 85.60 × 53.98 مم.', style: TextStyle(color: Color(0xFF758198), height: 1.5, fontSize: 12)),
    const SizedBox(height: 10), Row(children: [Expanded(child: _mmField('العرض (مم)', _widthMm, (v) => _widthMm = v, key: const ValueKey('width'))), const SizedBox(width: 12), Expanded(child: _mmField('الارتفاع (مم)', _heightMm, (v) => _heightMm = v, key: const ValueKey('height')))]),
    const SizedBox(height: 20), SizedBox(height: 52, child: FilledButton.icon(onPressed: _busy ? null : _previewPdf, icon: const Icon(Icons.picture_as_pdf_outlined), label: const Text('معاينة PDF والطباعة', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)))),
    if (_busy) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())), const SizedBox(height: 8), const Text('تنبيه: عند الطباعة اختر حجم الورق A4 ومقياس 100% أو Actual Size، وأوقف خيار Fit to page لضمان المقاس الحقيقي.', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF758198), height: 1.6, fontSize: 12)),
  ])));

  Widget _mmField(String label, double initial, ValueChanged<double> onChanged, {required Key key}) {
    return TextFormField(key: key, initialValue: initial.toStringAsFixed(2), keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: label, suffixText: 'مم', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))), onChanged: (value) { final n = double.tryParse(value); if (n != null && n > 0 && n < 300) onChanged(n); });
  }
}

class ToolIntroPage extends StatelessWidget { const ToolIntroPage({super.key, required this.tool}); final PrintTool tool; @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(tool.title)), body: Padding(padding: const EdgeInsets.all(22), child: Column(children: [const SizedBox(height: 25), Container(width: 90, height: 90, decoration: BoxDecoration(color: tool.color, borderRadius: BorderRadius.circular(26)), child: Icon(tool.icon, color: tool.iconColor, size: 45)), const SizedBox(height: 22), Text(tool.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: printoNavy)), const SizedBox(height: 10), Text(tool.subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF758198), fontSize: 15, height: 1.7)), const SizedBox(height: 24), Container(width: double.infinity, padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE8ECF4))), child: const Text('هذه الأداة ستُفعّل في مرحلة لاحقة. ميزة البطاقة الشخصية أصبحت جاهزة للتجربة.', textAlign: TextAlign.center, style: TextStyle(height: 1.7, color: printoNavy))), const Spacer(), SizedBox(width: double.infinity, child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('العودة للرئيسية')))]))); }

class SettingsPage extends StatelessWidget { const SettingsPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('الإعدادات')), body: ListView(padding: const EdgeInsets.all(18), children: const [ListTile(leading: Icon(Icons.straighten_outlined, color: printoBlue), title: Text('وحدات القياس'), subtitle: Text('مقاسات الطباعة بالملليمتر.')), Divider(height: 1), ListTile(leading: Icon(Icons.print_outlined, color: printoBlue), title: Text('إعدادات الطباعة'), subtitle: Text('تأكد من اختيار A4 والطباعة بمقياس 100%.')), Divider(height: 1), ListTile(leading: Icon(Icons.info_outline, color: printoBlue), title: Text('حول برينتو'), subtitle: Text('PRINTO — الطباعة الذكية في متناول يدك.'))])); }
