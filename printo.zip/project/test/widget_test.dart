import 'package:flutter_test/flutter_test.dart';
import 'package:printo/main.dart';

void main() {
  testWidgets('PRINTO home page renders core tools', (tester) async {
    await tester.pumpWidget(const PrintoApp());
    expect(find.text('برينتو'), findsOneWidget);
    expect(find.text('ماذا تريد أن تطبع؟'), findsOneWidget);
    expect(find.text('بطاقة شخصية'), findsWidgets);
  });
}
