# PRINTO | برينتو

Flutter Android app for preparing photos and documents for printing.

## P0 implemented: ID card to A4 PDF
- Capture the front/back of a card with the phone camera or select images from the gallery.
- Crop each side before use.
- Place both sides on an A4 PDF using a default card size of 85.60 × 53.98 mm (ISO ID-1).
- Change width/height in millimeters when the physical card differs.
- Open the system print preview and save/share the PDF through Android's print service.
- Image processing is local; the app does not upload photos to a server.

## Printing note
For physical size accuracy, choose A4 and `100%` / `Actual size` in the print dialog and disable `Fit to page`. Actual printed size also depends on the printer and driver.

## Build
The GitHub Actions workflow generates Android platform files, resolves dependencies, runs analysis/tests, and builds a release APK.
